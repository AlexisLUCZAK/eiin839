﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Part2
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            try
            {
                HttpClient Client = new HttpClient();
                string contract = "lyon";
                string responseBody = await Client.GetStringAsync("https://api.jcdecaux.com/vls/v1/stations?contract=" + contract + "&apiKey=8832bc606f866bd31eddff789078bdc28f9eb5de");
                Console.WriteLine(responseBody);
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine("\nException Caught!");
                Console.WriteLine("Message :{0} ", e.Message);
            }
        }
    }
}
