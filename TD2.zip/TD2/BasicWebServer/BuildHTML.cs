namespace BasicServerHTTPlistener

   internal class BuildHTML
{
    public string generate()
    {
        return "<!doctype html>" +
            '<html lang="fr">' +
            '<head>' +
            '<title>SOC TD 2</title>' +
            '</head>' +
            '<body>' +
            '<h1> Page HTML </h1>' +
            '</body>' +
            '</html>'; 


    }
}