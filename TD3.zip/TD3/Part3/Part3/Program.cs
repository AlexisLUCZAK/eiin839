﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Part3
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            try
            {
                HttpClient Client = new HttpClient();
                string contract = "lyon";
                string responseBody = await Client.GetStringAsync("https://api.jcdecaux.com/vls/v1/stations?contract=" + contract + "&apiKey=8832bc606f866bd31eddff789078bdc28f9eb5de");

                List<Station> listStations = JsonConvert.DeserializeObject<List<Station>>(responseBody);
                
                for(int i = 0; i < listStations.Count; i++)
                {
                    Console.WriteLine("Station n° " + i.ToString());
                    Console.WriteLine("Info : ");
                    Console.WriteLine(listStations[i].ToString());
                }
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine("\nException Caught!");
                Console.WriteLine("Message :{0} ", e.Message);
            }
        }
    }

    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
    internal class Station
    {
 
        public int number { get; set; }
        public string contract_name { get; set; }
        public string name { get; set; }
        public string address { get; set; }
        public Position position { get; set; }
        public bool banking { get; set; }
        public bool bonus { get; set; }
        public int bike_stands { get; set; }
        public int available_bike_stands { get; set; }
        public int available_bikes { get; set; }
        public string status { get; set; }
        public long last_update { get; set; }

        public override string ToString()
        {
            return $"   Number: {number}\n" +
                   $"   Contrat name: {contract_name}\n" +
                   $"   Name: {name}\n" +
                   $"   Address: {address}\n" +
                   $"   Position: \n{position}\n" +
                   $"   Banking: {banking}\n" +
                   $"   Bonus: {bonus}\n" +
                   $"   Bike stands: {bike_stands}\n" +
                   $"   Available bike stands: {available_bike_stands}\n" +
                   $"   Available bikes: {available_bikes}\n" +
                   $"   Status: {status}\n" +
                   $"   Last update: {last_update}\n";
        }
    }

    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
    internal class Position
    {
        public double lat { get; set; }
        public double lng { get; set; }

        public override string ToString()
        {
            return $"   -Latitude: {lat}\n" +
                   $"   -Longitude: {lng}";
        }
    }
}
