﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Diagnostics;
using System.IO;


namespace ExterneExec
{
    internal class Program
    {
        static void Main(string[] args)
        {
            if (args.Length == 1)
                Console.WriteLine("Polytech LUCZAK Alexis participe à l'évenement : " + args[0]);
            else if (args.Length == 2)
                Console.WriteLine("Polytech LUCZAK Alexis participe à l'évenement : " + args[0] + " avec son ami : " + args[1]);
            else
                Console.WriteLine("Polytech LUCZAK Alexis ne participe pas à l'évenement");
        }
    }
}
