namespace BasicServerHTTPlistener
{
     public class MyMethod
    {

        public string generate()
        {
            return "<!doctype html>" +
                '<html lang="fr">' +
                '<head>' +
                '<title>SOC TD 2</title>' +
                '</head>' +
                '<body>' +
                '<h1> Page HTML </h1>' +
                '</body>' +
                '</html>';


        }

        // http://localhost:8080/myMethod?par1=a&par2=b
        public string generateHTML(string param1, string param2)
        {
            return "<html><body> Hello " + param1 + " et " + param2 + "</body></html>";


        }

    }
}

