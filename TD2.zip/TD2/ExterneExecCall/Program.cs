﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Diagnostics;
using System.IO;


namespace ExterneExecCall
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //
            // Set up the process with the ProcessStartInfo class.
            // https://www.dotnetperls.com/process
            //
            ProcessStartInfo start = new ProcessStartInfo();
            start.FileName = @"D:\SOC\eiin839\TD2\ExterneExec\bin\Debug\ExecTest.exe"; // Specify exe name.
            if (args.Length == 1)
            {
                start.Arguments = args[0];
            }
            else if (args.Length == 2)
            {
                start.Arguments = $"{args[0]} {args[1]}";
            }

            else
            {
                start.Arguments = "Arg test";
            }
                

            // Specify arguments.
            start.UseShellExecute = false;
            start.RedirectStandardOutput = true;
            //
            // Start the process.
            //
            using (Process process = Process.Start(start))
            {
                //
                // Read in all the text from the process with the StreamReader.
                //
                using (StreamReader reader = process.StandardOutput)
                {
                    string result = reader.ReadToEnd();
                    Console.WriteLine(result);
                    Console.ReadLine();
                }
            }
        }
    }
}
