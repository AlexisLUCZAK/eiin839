﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartServiceSOAP
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var calculatorASMX = new CalculatorASMX.CalculatorSoapClient();

            Console.WriteLine("Division :");
            Console.WriteLine(calculatorASMX.Divide(8, 2));


            Console.WriteLine("Addition :");
            Console.WriteLine(calculatorASMX.Add(10, 2));


            Console.WriteLine("Soustraction :");
            Console.WriteLine(calculatorASMX.Subtract(5, 5));


            Console.WriteLine("Multiplication :");
            Console.WriteLine(calculatorASMX.Multiply(7, 10));
        }
    }
}
