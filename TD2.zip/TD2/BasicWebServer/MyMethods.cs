﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Diagnostics;
using System.IO;

namespace BasicWebServer
{
    internal class MyMethods
    {
        //http://localhost:8080/generate?par1=alex&par2=luczak
        public string generate(string param1, string param2)
        {
            return "<!doctype html>" +
                "<head>" +
                "<title>SOC TD 2</title>" +
                "</head>" +
                "<body>" +
                "<h1> Page HTML intro </h1>" +
                "<p> Param 1: " + param1 + " et param 2: " + param2 + "</p>" +
                "</body>" +
                "</html>";


        }

        //http://localhost:8080/generateHTML?par1=alex&par2=luczak
        public string generateHTML(string param1, string param2)
        {
            return "<html><body> Bonjour  " + param1 + " et " + param2 + "</body></html>";


        }

        //http://localhost:8080/callExt?par1=BotaEvent&par2=Flo
        public string callExt(string param1, string param2)
        {
            //
            ProcessStartInfo start = new ProcessStartInfo();
            start.FileName = @"D:\SOC\eiin839\TD2\ExterneExec\bin\Debug\ExterneExec.exe"; // Specify exe name.
            start.Arguments = $"{param1} {param2}"; // Specify arguments.
            start.UseShellExecute = false;
            start.RedirectStandardOutput = true;
            //
            // Start the process.
            //

            string resultToSend = "";

            using (Process process = Process.Start(start))
            {
                //
                // Read in all the text from the process with the StreamReader.
                //
                using (StreamReader reader = process.StandardOutput)
                {
                    string result = reader.ReadToEnd();
                    Console.WriteLine(result);
                   
                    resultToSend = result;
                }
            }

            Console.WriteLine("Result to send : " + resultToSend);

            return resultToSend;
        }
    }
}
